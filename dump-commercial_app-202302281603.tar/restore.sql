--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.10
-- Dumped by pg_dump version 11.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE commercial_app;
--
-- Name: commercial_app; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE commercial_app WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_India.1252' LC_CTYPE = 'English_India.1252';


ALTER DATABASE commercial_app OWNER TO postgres;

\connect commercial_app

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: app_users_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_users_master (
    user_id integer NOT NULL,
    name character varying(30),
    username character varying(30),
    email_id character varying(255),
    password character varying(255),
    is_delete integer,
    status character varying(15),
    createdat timestamp with time zone NOT NULL,
    updatedat timestamp with time zone NOT NULL,
    is_admin integer
);


ALTER TABLE public.app_users_master OWNER TO postgres;

--
-- Name: app_users_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.app_users_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.app_users_id OWNER TO postgres;

--
-- Name: app_users_id; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.app_users_id OWNED BY public.app_users_master.user_id;


--
-- Name: category_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_master (
    category_id integer NOT NULL,
    category_name character varying,
    category_description character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_delete integer DEFAULT 0
);


ALTER TABLE public.category_master OWNER TO postgres;

--
-- Name: category_item_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_item_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_item_id OWNER TO postgres;

--
-- Name: category_item_id; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_item_id OWNED BY public.category_master.category_id;


--
-- Name: product_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_master (
    product_id integer NOT NULL,
    _category_id integer NOT NULL,
    product_name character varying NOT NULL,
    product_description character varying,
    product_price numeric,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_delete integer DEFAULT 0
);


ALTER TABLE public.product_master OWNER TO postgres;

--
-- Name: order_item_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_item_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_item_id OWNER TO postgres;

--
-- Name: order_item_id; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_item_id OWNED BY public.product_master.product_id;


--
-- Name: product_item_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_item_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_item_id OWNER TO postgres;

--
-- Name: product_item_id; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_item_id OWNED BY public.product_master.product_id;


--
-- Name: users_cart_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_cart_master (
    users_product_id integer NOT NULL,
    _product_id integer NOT NULL,
    _category_id integer NOT NULL,
    _user_id integer NOT NULL,
    is_delete integer DEFAULT 0,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.users_cart_master OWNER TO postgres;

--
-- Name: users_cart_item_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_cart_item_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_cart_item_id OWNER TO postgres;

--
-- Name: users_cart_item_id; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_cart_item_id OWNED BY public.users_cart_master.users_product_id;


--
-- Name: app_users_master user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_users_master ALTER COLUMN user_id SET DEFAULT nextval('public.app_users_id'::regclass);


--
-- Name: category_master category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_master ALTER COLUMN category_id SET DEFAULT nextval('public.category_item_id'::regclass);


--
-- Name: product_master product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_master ALTER COLUMN product_id SET DEFAULT nextval('public.product_item_id'::regclass);


--
-- Name: users_cart_master users_product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_cart_master ALTER COLUMN users_product_id SET DEFAULT nextval('public.users_cart_item_id'::regclass);


--
-- Data for Name: app_users_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_users_master (user_id, name, username, email_id, password, is_delete, status, createdat, updatedat, is_admin) FROM stdin;
\.
COPY public.app_users_master (user_id, name, username, email_id, password, is_delete, status, createdat, updatedat, is_admin) FROM '$$PATH$$/2844.dat';

--
-- Data for Name: category_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_master (category_id, category_name, category_description, created_at, updated_at, is_delete) FROM stdin;
\.
COPY public.category_master (category_id, category_name, category_description, created_at, updated_at, is_delete) FROM '$$PATH$$/2845.dat';

--
-- Data for Name: product_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_master (product_id, _category_id, product_name, product_description, product_price, created_at, updated_at, is_delete) FROM stdin;
\.
COPY public.product_master (product_id, _category_id, product_name, product_description, product_price, created_at, updated_at, is_delete) FROM '$$PATH$$/2846.dat';

--
-- Data for Name: users_cart_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_cart_master (users_product_id, _product_id, _category_id, _user_id, is_delete, created_at, updated_at) FROM stdin;
\.
COPY public.users_cart_master (users_product_id, _product_id, _category_id, _user_id, is_delete, created_at, updated_at) FROM '$$PATH$$/2847.dat';

--
-- Name: app_users_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.app_users_id', 1, false);


--
-- Name: category_item_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_item_id', 1, false);


--
-- Name: order_item_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_item_id', 1, false);


--
-- Name: product_item_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_item_id', 17, true);


--
-- Name: users_cart_item_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_cart_item_id', 2, true);


--
-- Name: app_users_master app_users_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_users_master
    ADD CONSTRAINT app_users_master_pkey PRIMARY KEY (user_id);


--
-- Name: category_master category_master_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_master
    ADD CONSTRAINT category_master_pk PRIMARY KEY (category_id);


--
-- Name: product_master product_master_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_master
    ADD CONSTRAINT product_master_pk PRIMARY KEY (product_id);


--
-- Name: users_cart_master users_cart_master_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_cart_master
    ADD CONSTRAINT users_cart_master_pk PRIMARY KEY (users_product_id);


--
-- PostgreSQL database dump complete
--

